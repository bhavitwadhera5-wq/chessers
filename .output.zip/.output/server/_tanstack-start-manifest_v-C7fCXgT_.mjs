//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C7fCXgT_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/HP/Documents/Chessers-Pro/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/leaderboard",
			"/puzzles",
			"/sitemap.xml",
			"/solo",
			"/play/$gameId"
		],
		preloads: ["/assets/index-By2OZUL5.js", "/assets/useRouter-BQ61MA5v.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-By2OZUL5.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/HP/Documents/Chessers-Pro/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DwqlePQ2.js",
			"/assets/auth-middleware--C-gYQvh.js",
			"/assets/boardThemes-j2_-YYBO.js",
			"/assets/games.functions-DLJaCjNR.js"
		]
	},
	"/admin": {
		filePath: "C:/Users/HP/Documents/Chessers-Pro/src/routes/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-CTnB-vBm.js", "/assets/auth-middleware--C-gYQvh.js"]
	},
	"/leaderboard": {
		filePath: "C:/Users/HP/Documents/Chessers-Pro/src/routes/leaderboard.tsx",
		children: void 0,
		preloads: ["/assets/leaderboard-KwPIfQ-X.js", "/assets/humanBots-0LtFFWUB.js"]
	},
	"/puzzles": {
		filePath: "C:/Users/HP/Documents/Chessers-Pro/src/routes/puzzles.tsx",
		children: void 0,
		preloads: [
			"/assets/puzzles-B1ikFzsL.js",
			"/assets/boardThemes-j2_-YYBO.js",
			"/assets/chess-ChQH7pbr.js",
			"/assets/sounds-CdWsviGw.js"
		]
	},
	"/solo": {
		filePath: "C:/Users/HP/Documents/Chessers-Pro/src/routes/solo.tsx",
		children: void 0,
		preloads: [
			"/assets/solo-p6ZpPV9N.js",
			"/assets/boardThemes-j2_-YYBO.js",
			"/assets/chess-ChQH7pbr.js",
			"/assets/engine-BniCeKTo.js",
			"/assets/sounds-CdWsviGw.js",
			"/assets/MoveList-BI1v-RYz.js"
		]
	},
	"/play/$gameId": {
		filePath: "C:/Users/HP/Documents/Chessers-Pro/src/routes/play.$gameId.tsx",
		children: void 0,
		preloads: [
			"/assets/play._gameId-Dm6zINW8.js",
			"/assets/auth-middleware--C-gYQvh.js",
			"/assets/boardThemes-j2_-YYBO.js",
			"/assets/games.functions-DLJaCjNR.js",
			"/assets/chess-ChQH7pbr.js",
			"/assets/humanBots-0LtFFWUB.js",
			"/assets/sounds-CdWsviGw.js",
			"/assets/MoveList-BI1v-RYz.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
