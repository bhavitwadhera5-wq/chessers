import { n as createServerFn } from "./server-TUNRzD0E.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-T8rJsk6L.mjs";
import { t as createServerRpc } from "./createServerRpc-Bcm1zZV-.mjs";
import { t as Chess } from "../_libs/chess.js.mjs";
import { a as pickHumanBot } from "./humanBots-GpmBr8cf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/games.functions-EZ_Bv1QE.js
function ratingAfter(current, opponent, result, k = 24) {
	const expected = 1 / (1 + 10 ** ((opponent - current) / 400));
	return Math.max(100, Math.round(current + k * (result - expected)));
}
/** Applies online rating changes once per finished game (service role). */
async function applyRatings(gameId) {
	const { supabaseAdmin } = await import("./client.server-Bw6iWMJ-.mjs");
	const { data: game } = await supabaseAdmin.from("games").select("id, white_id, black_id, result, status, elo_applied, bot_name, bot_elo").eq("id", gameId).maybeSingle();
	if (!game || game.status !== "finished" || game.elo_applied) return;
	if (game.bot_name && (!game.white_id || !game.black_id)) {
		const humanId = game.white_id ?? game.black_id;
		if (!humanId) return;
		const humanIsWhite = !!game.white_id;
		const { data: profile } = await supabaseAdmin.from("profiles").select("id, elo").eq("id", humanId).maybeSingle();
		if (!profile) return;
		const score = game.result === "draw" ? .5 : game.result === (humanIsWhite ? "white" : "black") ? 1 : 0;
		const next = ratingAfter(profile.elo, game.bot_elo ?? profile.elo, score);
		await supabaseAdmin.from("profiles").update({ elo: next }).eq("id", humanId);
		await supabaseAdmin.from("games").update({ elo_applied: true }).eq("id", gameId);
		return;
	}
	if (!game.white_id || !game.black_id) return;
	const { data: rows } = await supabaseAdmin.from("profiles").select("id, elo").in("id", [game.white_id, game.black_id]);
	const white = rows?.find((r) => r.id === game.white_id);
	const black = rows?.find((r) => r.id === game.black_id);
	if (!white || !black) return;
	const whiteScore = game.result === "white" ? 1 : game.result === "black" ? 0 : .5;
	const newWhite = ratingAfter(white.elo, black.elo, whiteScore);
	const newBlack = ratingAfter(black.elo, white.elo, 1 - whiteScore);
	await supabaseAdmin.from("profiles").update({ elo: newWhite }).eq("id", white.id);
	await supabaseAdmin.from("profiles").update({ elo: newBlack }).eq("id", black.id);
	await supabaseAdmin.from("games").update({ elo_applied: true }).eq("id", gameId);
}
var findOrCreateGame_createServerFn_handler = createServerRpc({
	id: "7c89d1e873fad3f4339751da3a4b7f5bc5c54ccaad6d7c651c68d5492d4fc749",
	name: "findOrCreateGame",
	filename: "src/lib/games.functions.ts"
}, (opts) => findOrCreateGame.__executeServer(opts));
var findOrCreateGame = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(findOrCreateGame_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const wanted = (data.opponentUsername ?? "").trim().toLowerCase() || null;
	const minutes = [
		0,
		5,
		10
	].includes(Number(data.minutes)) ? Number(data.minutes) : 0;
	const pref = data.color ?? "w";
	const myColor = pref === "random" ? Math.random() < .5 ? "w" : "b" : pref;
	const { data: me } = await supabase.from("profiles").select("username, banned, ban_reason").eq("id", userId).maybeSingle();
	if (me?.banned) throw new Error(me.ban_reason ? `Your account is banned: ${me.ban_reason}` : "Your account is banned from online play.");
	const myUsername = me?.username ?? null;
	let matchedName = null;
	if (wanted) {
		const { data: target } = await supabase.from("profiles").select("id, username").eq("username", wanted).maybeSingle();
		if (target && target.id !== userId) matchedName = target.username;
	}
	const seat = myColor === "w" ? "white_id" : "black_id";
	const otherSeat = myColor === "w" ? "black_id" : "white_id";
	const { data: waiting } = await supabase.from("games").select("id, white_id, black_id, invited_username, time_control").eq("status", "waiting").eq("time_control", minutes).is(seat, null).not(otherSeat, "is", null).order("created_at", { ascending: true }).limit(20);
	const candidates = (waiting ?? []).filter((g) => g[otherSeat] !== userId && (!g.invited_username || myUsername && g.invited_username === myUsername));
	const preferred = candidates.find((g) => myUsername && g.invited_username === myUsername) ?? candidates[0];
	if (preferred) {
		const clockMs = minutes ? minutes * 6e4 : null;
		const { data: joined, error } = await supabase.from("games").update({
			white_id: myColor === "w" ? userId : preferred.white_id,
			black_id: myColor === "b" ? userId : preferred.black_id,
			status: "active",
			white_ms: clockMs,
			black_ms: clockMs,
			turn_started_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("id", preferred.id).eq("status", "waiting").is(seat, null).select("id").maybeSingle();
		if (!error && joined) return {
			gameId: joined.id,
			mode: "joined",
			opponent: null,
			color: myColor,
			unknownUsername: wanted !== null && matchedName === null
		};
	}
	const { data: created, error: createError } = await supabase.from("games").insert({
		white_id: myColor === "w" ? userId : null,
		black_id: myColor === "b" ? userId : null,
		invited_username: matchedName,
		time_control: minutes
	}).select("id").single();
	if (createError || !created) throw new Error("Could not create a game.");
	return {
		gameId: created.id,
		mode: matchedName ? "invited" : "open",
		opponent: matchedName,
		color: myColor,
		unknownUsername: wanted !== null && matchedName === null
	};
});
var makeMove_createServerFn_handler = createServerRpc({
	id: "4729b461ab9e7f95edbc2066531e6119c7ef1c4ef291f5167be40c95b0ca16f9",
	name: "makeMove",
	filename: "src/lib/games.functions.ts"
}, (opts) => makeMove.__executeServer(opts));
var makeMove = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(makeMove_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: game } = await supabase.from("games").select("id, white_id, black_id, fen, status, time_control, white_ms, black_ms, turn_started_at").eq("id", data.gameId).maybeSingle();
	if (!game) throw new Error("Game not found.");
	if (game.status !== "active") throw new Error("This game is not in play.");
	const myColor = game.white_id === userId ? "w" : game.black_id === userId ? "b" : null;
	if (!myColor) throw new Error("You are not a player in this game.");
	const chess = new Chess(game.fen);
	if (chess.turn() !== myColor) throw new Error("It is not your turn.");
	let whiteMs = game.white_ms;
	let blackMs = game.black_ms;
	if (game.time_control > 0 && game.turn_started_at) {
		const elapsed = Date.now() - new Date(game.turn_started_at).getTime();
		const left = ((myColor === "w" ? whiteMs : blackMs) ?? game.time_control * 6e4) - elapsed;
		if (left <= 0) {
			await supabase.from("games").update({
				status: "finished",
				result: myColor === "w" ? "black" : "white",
				white_ms: myColor === "w" ? 0 : whiteMs,
				black_ms: myColor === "b" ? 0 : blackMs
			}).eq("id", game.id);
			await applyRatings(game.id);
			throw new Error("Your time ran out.");
		}
		if (myColor === "w") whiteMs = left;
		else blackMs = left;
	}
	try {
		chess.move({
			from: data.from,
			to: data.to,
			promotion: "q"
		});
	} catch {
		throw new Error("Illegal move.");
	}
	const over = chess.isGameOver();
	let result = null;
	if (over) if (chess.isCheckmate()) result = chess.turn() === "w" ? "black" : "white";
	else result = "draw";
	const { error } = await supabase.from("games").update({
		fen: chess.fen(),
		last_move: `${data.from}${data.to}`,
		status: over ? "finished" : "active",
		result,
		white_ms: whiteMs,
		black_ms: blackMs,
		turn_started_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", game.id);
	if (error) throw new Error("Could not save your move.");
	if (over) await applyRatings(game.id);
	return {
		fen: chess.fen(),
		status: over ? "finished" : "active",
		result,
		white_ms: whiteMs,
		black_ms: blackMs
	};
});
var claimTimeout_createServerFn_handler = createServerRpc({
	id: "54831cd06c61e074e7534b463a8cd8b493da9baa80e973f1404530dc5ff100d0",
	name: "claimTimeout",
	filename: "src/lib/games.functions.ts"
}, (opts) => claimTimeout.__executeServer(opts));
var claimTimeout = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(claimTimeout_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: game } = await supabase.from("games").select("id, white_id, black_id, fen, status, time_control, white_ms, black_ms, turn_started_at").eq("id", data.gameId).maybeSingle();
	if (!game) throw new Error("Game not found.");
	if (game.status !== "active" || !game.time_control) return { ok: false };
	if (game.white_id !== userId && game.black_id !== userId) throw new Error("You are not a player in this game.");
	const turn = new Chess(game.fen).turn();
	if (((turn === "w" ? game.white_ms : game.black_ms) ?? game.time_control * 6e4) - (game.turn_started_at ? Date.now() - new Date(game.turn_started_at).getTime() : 0) > 0) return { ok: false };
	await supabase.from("games").update({
		status: "finished",
		result: turn === "w" ? "black" : "white",
		white_ms: turn === "w" ? 0 : game.white_ms,
		black_ms: turn === "b" ? 0 : game.black_ms
	}).eq("id", game.id);
	await applyRatings(game.id);
	return { ok: true };
});
var resignGame_createServerFn_handler = createServerRpc({
	id: "c53c2b171816dd0c5a50865e9569ff93244d2193ffbb0da9d33ce4953ed6aa75",
	name: "resignGame",
	filename: "src/lib/games.functions.ts"
}, (opts) => resignGame.__executeServer(opts));
var resignGame = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(resignGame_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: game } = await supabase.from("games").select("id, white_id, black_id, status").eq("id", data.gameId).maybeSingle();
	if (!game) throw new Error("Game not found.");
	const myColor = game.white_id === userId ? "w" : game.black_id === userId ? "b" : null;
	if (!myColor) throw new Error("You are not a player in this game.");
	await supabase.from("games").update({
		status: "finished",
		result: myColor === "w" ? "black" : "white"
	}).eq("id", game.id);
	await applyRatings(game.id);
	return { ok: true };
});
var agreeDraw_createServerFn_handler = createServerRpc({
	id: "b76842116856c5549ee4b720305aa5b9ee88c3d7fd6bb32282a47c0e0af7745a",
	name: "agreeDraw",
	filename: "src/lib/games.functions.ts"
}, (opts) => agreeDraw.__executeServer(opts));
var agreeDraw = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(agreeDraw_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: game } = await supabase.from("games").select("id, white_id, black_id, status").eq("id", data.gameId).maybeSingle();
	if (!game) throw new Error("Game not found.");
	if (game.white_id !== userId && game.black_id !== userId) throw new Error("You are not a player in this game.");
	if (game.status !== "active") throw new Error("This game is not in play.");
	await supabase.from("games").update({
		status: "finished",
		result: "draw"
	}).eq("id", game.id);
	await applyRatings(game.id);
	return { ok: true };
});
var fillWithBot_createServerFn_handler = createServerRpc({
	id: "fa9fc95427da78d1e177c789a6ba700580cada50f5fb424a81eee4e1c4e568fe",
	name: "fillWithBot",
	filename: "src/lib/games.functions.ts"
}, (opts) => fillWithBot.__executeServer(opts));
var fillWithBot = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(fillWithBot_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: game } = await supabase.from("games").select("id, white_id, black_id, status, time_control, bot_name").eq("id", data.gameId).maybeSingle();
	if (!game) throw new Error("Game not found.");
	if (game.white_id !== userId && game.black_id !== userId) throw new Error("You are not a player in this game.");
	if (game.status !== "waiting") return {
		filled: false,
		botName: game.bot_name
	};
	if (game.white_id && game.black_id) return {
		filled: false,
		botName: null
	};
	const { data: me } = await supabase.from("profiles").select("elo").eq("id", userId).maybeSingle();
	const bot = pickHumanBot(me?.elo ?? 1e3);
	const clockMs = game.time_control ? game.time_control * 6e4 : null;
	const { error } = await supabase.from("games").update({
		status: "active",
		bot_name: bot.name,
		bot_elo: bot.elo,
		invited_username: null,
		white_ms: clockMs,
		black_ms: clockMs,
		turn_started_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", game.id).eq("status", "waiting");
	if (error) throw new Error("Could not start the match.");
	return {
		filled: true,
		botName: bot.name,
		botElo: bot.elo
	};
});
var botPlayMove_createServerFn_handler = createServerRpc({
	id: "79f7500f37bcbd972b3ae9fafeb36e137de69c0cf837f0143fcac4fb35fe9b36",
	name: "botPlayMove",
	filename: "src/lib/games.functions.ts"
}, (opts) => botPlayMove.__executeServer(opts));
var botPlayMove = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(botPlayMove_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: game } = await supabase.from("games").select("id, white_id, black_id, fen, status, time_control, white_ms, black_ms, turn_started_at, bot_name").eq("id", data.gameId).maybeSingle();
	if (!game) throw new Error("Game not found.");
	if (!game.bot_name) throw new Error("This game has no computer opponent.");
	if (game.status !== "active") throw new Error("This game is not in play.");
	const myColor = game.white_id === userId ? "w" : game.black_id === userId ? "b" : null;
	if (!myColor) throw new Error("You are not a player in this game.");
	const botColor = myColor === "w" ? "b" : "w";
	if ((botColor === "w" ? game.white_id : game.black_id) !== null) throw new Error("That seat is taken by a player.");
	const chess = new Chess(game.fen);
	if (chess.turn() !== botColor) throw new Error("It is not the opponent's turn.");
	let whiteMs = game.white_ms;
	let blackMs = game.black_ms;
	if (game.time_control > 0 && game.turn_started_at) {
		const elapsed = Date.now() - new Date(game.turn_started_at).getTime();
		const left = ((botColor === "w" ? whiteMs : blackMs) ?? game.time_control * 6e4) - elapsed;
		if (left <= 0) {
			await supabase.from("games").update({
				status: "finished",
				result: botColor === "w" ? "black" : "white",
				white_ms: botColor === "w" ? 0 : whiteMs,
				black_ms: botColor === "b" ? 0 : blackMs
			}).eq("id", game.id);
			await applyRatings(game.id);
			return {
				fen: game.fen,
				status: "finished",
				result: botColor === "w" ? "black" : "white"
			};
		}
		if (botColor === "w") whiteMs = left;
		else blackMs = left;
	}
	try {
		chess.move({
			from: data.from,
			to: data.to,
			promotion: "q"
		});
	} catch {
		throw new Error("Illegal move.");
	}
	const over = chess.isGameOver();
	let result = null;
	if (over) result = chess.isCheckmate() ? chess.turn() === "w" ? "black" : "white" : "draw";
	const { error } = await supabase.from("games").update({
		fen: chess.fen(),
		last_move: `${data.from}${data.to}`,
		status: over ? "finished" : "active",
		result,
		white_ms: whiteMs,
		black_ms: blackMs,
		turn_started_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", game.id);
	if (error) throw new Error("Could not save the move.");
	if (over) await applyRatings(game.id);
	return {
		fen: chess.fen(),
		status: over ? "finished" : "active",
		result
	};
});
//#endregion
export { agreeDraw_createServerFn_handler, botPlayMove_createServerFn_handler, claimTimeout_createServerFn_handler, fillWithBot_createServerFn_handler, findOrCreateGame_createServerFn_handler, makeMove_createServerFn_handler, resignGame_createServerFn_handler };
