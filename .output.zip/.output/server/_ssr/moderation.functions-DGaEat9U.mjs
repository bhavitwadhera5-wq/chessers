import { n as createServerFn } from "./server-TUNRzD0E.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-T8rJsk6L.mjs";
import { t as createServerRpc } from "./createServerRpc-Bcm1zZV-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/moderation.functions-DGaEat9U.js
var REASON_IDS = [
	{
		id: "cheating",
		label: "Cheating / engine use"
	},
	{
		id: "sandbagging",
		label: "Sandbagging (losing on purpose)"
	},
	{
		id: "abuse",
		label: "Abusive behaviour"
	},
	{
		id: "stalling",
		label: "Stalling / disconnecting"
	},
	{
		id: "other",
		label: "Something else"
	}
].map((r) => r.id);
/** Files a report against the opponent in one of the caller's games. */
var reportOpponent_createServerFn_handler = createServerRpc({
	id: "ead9869751f05fbb7f10c05880c3e1d0a463c80c5dd8793e964710a8d2f85baa",
	name: "reportOpponent",
	filename: "src/lib/moderation.functions.ts"
}, (opts) => reportOpponent.__executeServer(opts));
var reportOpponent = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(reportOpponent_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	if (!REASON_IDS.includes(data.reason)) throw new Error("Unknown report reason.");
	const details = (data.details ?? "").slice(0, 1e3) || null;
	let reportedId = null;
	let reportedUsername = null;
	let engineMatch = null;
	let accuracy = null;
	if (data.gameId) {
		const { data: game } = await supabase.from("games").select("id, white_id, black_id").eq("id", data.gameId).maybeSingle();
		if (!game || game.white_id !== userId && game.black_id !== userId) throw new Error("You can only report opponents from your own games.");
		reportedId = game.white_id === userId ? game.black_id : game.white_id;
		if (reportedId) {
			const { data: profile } = await supabase.from("profiles").select("username").eq("id", reportedId).maybeSingle();
			reportedUsername = profile?.username ?? null;
			const { data: flag } = await supabase.from("fair_play_flags").select("engine_match, accuracy").eq("game_id", data.gameId).eq("player_id", reportedId).maybeSingle();
			engineMatch = flag?.engine_match ?? null;
			accuracy = flag?.accuracy ?? null;
		}
	}
	const { error } = await supabase.from("reports").insert({
		reporter_id: userId,
		reported_id: reportedId,
		reported_username: reportedUsername,
		game_id: data.gameId ?? null,
		reason: data.reason,
		details,
		engine_match: engineMatch,
		accuracy
	});
	if (error) throw new Error(error.message);
	return { ok: true };
});
/** Stores post-game fair-play statistics for both players of a finished game. */
var submitFairPlay_createServerFn_handler = createServerRpc({
	id: "c136811f6020ce02f020d92d8cabe7bf91cf5edfcdc0f55cfb280e27d76222b5",
	name: "submitFairPlay",
	filename: "src/lib/moderation.functions.ts"
}, (opts) => submitFairPlay.__executeServer(opts));
var submitFairPlay = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(submitFairPlay_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: game } = await supabase.from("games").select("id, white_id, black_id, status").eq("id", data.gameId).maybeSingle();
	if (!game || game.white_id !== userId && game.black_id !== userId) throw new Error("Not your game.");
	if (game.status !== "finished") return { ok: false };
	const rows = data.stats.map((s) => ({
		game_id: game.id,
		player_id: s.color === "w" ? game.white_id : game.black_id,
		engine_match: Math.max(0, Math.min(100, s.engineMatch)),
		accuracy: Math.max(0, Math.min(100, s.accuracy)),
		moves: Math.max(0, Math.round(s.moves)),
		suspicion: [
			"clean",
			"review",
			"high"
		].includes(s.suspicion) ? s.suspicion : "clean"
	})).filter((r) => Boolean(r.player_id));
	if (!rows.length) return { ok: false };
	const { supabaseAdmin } = await import("./client.server-Bw6iWMJ-.mjs");
	await supabaseAdmin.from("fair_play_flags").upsert(rows, { onConflict: "game_id,player_id" });
	const flagged = rows.filter((r) => r.suspicion === "high");
	for (const r of flagged) {
		const { data: existing } = await supabaseAdmin.from("reports").select("id").eq("game_id", game.id).eq("reported_id", r.player_id).eq("reason", "cheating").maybeSingle();
		if (existing) continue;
		await supabaseAdmin.from("reports").insert({
			reporter_id: r.player_id,
			reported_id: r.player_id,
			game_id: game.id,
			reason: "cheating",
			details: "Automatic fair-play review: engine-like move matching.",
			status: "auto",
			engine_match: r.engine_match,
			accuracy: r.accuracy
		});
	}
	return {
		ok: true,
		flagged: flagged.length
	};
});
var myReports_createServerFn_handler = createServerRpc({
	id: "e11da762a6722bcbc849cc9a7b60293c800eaf30b3024cf9825fcc7c419081aa",
	name: "myReports",
	filename: "src/lib/moderation.functions.ts"
}, (opts) => myReports.__executeServer(opts));
var myReports = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(myReports_createServerFn_handler, async ({ context }) => {
	const { data } = await context.supabase.from("reports").select("id, reported_username, reason, status, created_at").order("created_at", { ascending: false }).limit(20);
	return data ?? [];
});
//#endregion
export { myReports_createServerFn_handler, reportOpponent_createServerFn_handler, submitFairPlay_createServerFn_handler };
