import { t as Chess } from "../_libs/chess.js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-BXikbV55.js
var BOOK = {
	"e4": {
		eco: "B00",
		name: "King's Pawn Opening"
	},
	"d4": {
		eco: "A40",
		name: "Queen's Pawn Opening"
	},
	"c4": {
		eco: "A10",
		name: "English Opening"
	},
	"Nf3": {
		eco: "A04",
		name: "Réti Opening"
	},
	"g3": {
		eco: "A00",
		name: "Benko / Hungarian Opening"
	},
	"b3": {
		eco: "A01",
		name: "Nimzo-Larsen Attack"
	},
	"f4": {
		eco: "A02",
		name: "Bird's Opening"
	},
	"b4": {
		eco: "A00",
		name: "Polish (Sokolsky) Opening"
	},
	"Nc3": {
		eco: "A00",
		name: "Van Geet Opening"
	},
	"e3": {
		eco: "A00",
		name: "Van 't Kruijs Opening"
	},
	"d3": {
		eco: "A00",
		name: "Mieses Opening"
	},
	"g4": {
		eco: "A00",
		name: "Grob's Attack"
	},
	"e4 e5": {
		eco: "C20",
		name: "King's Pawn Game"
	},
	"e4 c5": {
		eco: "B20",
		name: "Sicilian Defence"
	},
	"e4 e6": {
		eco: "C00",
		name: "French Defence"
	},
	"e4 c6": {
		eco: "B10",
		name: "Caro-Kann Defence"
	},
	"e4 d5": {
		eco: "B01",
		name: "Scandinavian Defence"
	},
	"e4 d6": {
		eco: "B07",
		name: "Pirc Defence"
	},
	"e4 g6": {
		eco: "B06",
		name: "Modern Defence"
	},
	"e4 Nf6": {
		eco: "B02",
		name: "Alekhine's Defence"
	},
	"e4 Nc6": {
		eco: "B00",
		name: "Nimzowitsch Defence"
	},
	"e4 b6": {
		eco: "B00",
		name: "Owen's Defence"
	},
	"e4 e5 Nf3": {
		eco: "C40",
		name: "King's Knight Opening"
	},
	"e4 e5 Nf3 Nc6": {
		eco: "C44",
		name: "King's Knight, Normal Variation"
	},
	"e4 e5 Nf3 Nc6 Bb5": {
		eco: "C60",
		name: "Ruy López (Spanish Game)"
	},
	"e4 e5 Nf3 Nc6 Bb5 a6": {
		eco: "C68",
		name: "Ruy López, Morphy Defence"
	},
	"e4 e5 Nf3 Nc6 Bb5 a6 Ba4": {
		eco: "C70",
		name: "Ruy López, Morphy Defence"
	},
	"e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6": {
		eco: "C78",
		name: "Ruy López, Closed"
	},
	"e4 e5 Nf3 Nc6 Bb5 a6 Bxc6": {
		eco: "C68",
		name: "Ruy López, Exchange Variation"
	},
	"e4 e5 Nf3 Nc6 Bb5 Nf6": {
		eco: "C65",
		name: "Ruy López, Berlin Defence"
	},
	"e4 e5 Nf3 Nc6 Bc4": {
		eco: "C50",
		name: "Italian Game"
	},
	"e4 e5 Nf3 Nc6 Bc4 Bc5": {
		eco: "C50",
		name: "Giuoco Piano"
	},
	"e4 e5 Nf3 Nc6 Bc4 Bc5 b4": {
		eco: "C51",
		name: "Evans Gambit"
	},
	"e4 e5 Nf3 Nc6 Bc4 Nf6": {
		eco: "C55",
		name: "Two Knights Defence"
	},
	"e4 e5 Nf3 Nc6 Bc4 Nf6 Ng5": {
		eco: "C57",
		name: "Two Knights, Fried Liver Attack"
	},
	"e4 e5 Nf3 Nc6 d4": {
		eco: "C44",
		name: "Scotch Game"
	},
	"e4 e5 Nf3 Nc6 d4 exd4 Nxd4": {
		eco: "C45",
		name: "Scotch Game, Main Line"
	},
	"e4 e5 Nf3 Nc6 Nc3": {
		eco: "C46",
		name: "Three Knights Game"
	},
	"e4 e5 Nf3 Nc6 Nc3 Nf6": {
		eco: "C46",
		name: "Four Knights Game"
	},
	"e4 e5 Nf3 Nf6": {
		eco: "C42",
		name: "Petrov's (Russian) Defence"
	},
	"e4 e5 Nf3 d6": {
		eco: "C41",
		name: "Philidor Defence"
	},
	"e4 e5 Nf3 f5": {
		eco: "C40",
		name: "Latvian Gambit"
	},
	"e4 e5 f4": {
		eco: "C30",
		name: "King's Gambit"
	},
	"e4 e5 f4 exf4": {
		eco: "C33",
		name: "King's Gambit Accepted"
	},
	"e4 e5 f4 d5": {
		eco: "C31",
		name: "King's Gambit Declined, Falkbeer"
	},
	"e4 e5 Bc4": {
		eco: "C23",
		name: "Bishop's Opening"
	},
	"e4 e5 Nc3": {
		eco: "C25",
		name: "Vienna Game"
	},
	"e4 e5 d4": {
		eco: "C21",
		name: "Centre Game"
	},
	"e4 c5 Nf3": {
		eco: "B27",
		name: "Sicilian Defence"
	},
	"e4 c5 Nf3 d6": {
		eco: "B50",
		name: "Sicilian, Modern Variations"
	},
	"e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3": {
		eco: "B56",
		name: "Sicilian, Classical"
	},
	"e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6": {
		eco: "B90",
		name: "Sicilian, Najdorf"
	},
	"e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 g6": {
		eco: "B70",
		name: "Sicilian, Dragon"
	},
	"e4 c5 Nf3 d6 Bb5+": {
		eco: "B51",
		name: "Sicilian, Moscow Variation"
	},
	"e4 c5 Nf3 Nc6": {
		eco: "B30",
		name: "Sicilian, Old Sicilian"
	},
	"e4 c5 Nf3 Nc6 Bb5": {
		eco: "B30",
		name: "Sicilian, Rossolimo Attack"
	},
	"e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 e5": {
		eco: "B32",
		name: "Sicilian, Löwenthal"
	},
	"e4 c5 Nf3 e6": {
		eco: "B40",
		name: "Sicilian, French Variation"
	},
	"e4 c5 Nf3 e6 d4 cxd4 Nxd4 a6": {
		eco: "B42",
		name: "Sicilian, Kan Variation"
	},
	"e4 c5 Nf3 e6 d4 cxd4 Nxd4 Nc6": {
		eco: "B44",
		name: "Sicilian, Taimanov"
	},
	"e4 c5 Nc3": {
		eco: "B23",
		name: "Sicilian, Closed"
	},
	"e4 c5 c3": {
		eco: "B22",
		name: "Sicilian, Alapin Variation"
	},
	"e4 c5 d4": {
		eco: "B21",
		name: "Sicilian, Smith-Morra Gambit"
	},
	"e4 c5 f4": {
		eco: "B21",
		name: "Sicilian, Grand Prix Attack"
	},
	"e4 e6 d4": {
		eco: "C00",
		name: "French Defence"
	},
	"e4 e6 d4 d5": {
		eco: "C01",
		name: "French Defence, Main Line"
	},
	"e4 e6 d4 d5 e5": {
		eco: "C02",
		name: "French, Advance Variation"
	},
	"e4 e6 d4 d5 exd5": {
		eco: "C01",
		name: "French, Exchange Variation"
	},
	"e4 e6 d4 d5 Nc3": {
		eco: "C10",
		name: "French, Paulsen Variation"
	},
	"e4 e6 d4 d5 Nc3 Bb4": {
		eco: "C15",
		name: "French, Winawer Variation"
	},
	"e4 e6 d4 d5 Nc3 Nf6": {
		eco: "C11",
		name: "French, Classical Variation"
	},
	"e4 e6 d4 d5 Nd2": {
		eco: "C03",
		name: "French, Tarrasch Variation"
	},
	"e4 c6 d4": {
		eco: "B12",
		name: "Caro-Kann Defence"
	},
	"e4 c6 d4 d5": {
		eco: "B12",
		name: "Caro-Kann, Main Line"
	},
	"e4 c6 d4 d5 Nc3": {
		eco: "B15",
		name: "Caro-Kann, Main Line"
	},
	"e4 c6 d4 d5 Nd2": {
		eco: "B15",
		name: "Caro-Kann, Modern Variation"
	},
	"e4 c6 d4 d5 e5": {
		eco: "B12",
		name: "Caro-Kann, Advance Variation"
	},
	"e4 c6 d4 d5 exd5": {
		eco: "B13",
		name: "Caro-Kann, Exchange Variation"
	},
	"e4 c6 d4 d5 exd5 cxd5 c4": {
		eco: "B13",
		name: "Caro-Kann, Panov-Botvinnik Attack"
	},
	"e4 c6 Nf3": {
		eco: "B10",
		name: "Caro-Kann, Two Knights"
	},
	"e4 d5 exd5": {
		eco: "B01",
		name: "Scandinavian Defence"
	},
	"e4 d5 exd5 Qxd5": {
		eco: "B01",
		name: "Scandinavian, Main Line"
	},
	"e4 d5 exd5 Nf6": {
		eco: "B01",
		name: "Scandinavian, Modern Variation"
	},
	"e4 Nf6 e5": {
		eco: "B03",
		name: "Alekhine's Defence"
	},
	"e4 Nf6 e5 Nd5 d4 d6 c4": {
		eco: "B03",
		name: "Alekhine, Four Pawns Attack"
	},
	"e4 d6 d4 Nf6 Nc3": {
		eco: "B07",
		name: "Pirc Defence"
	},
	"e4 d6 d4 Nf6 Nc3 g6": {
		eco: "B08",
		name: "Pirc, Classical"
	},
	"e4 g6 d4 Bg7": {
		eco: "B06",
		name: "Modern Defence"
	},
	"d4 d5": {
		eco: "D00",
		name: "Queen's Pawn Game"
	},
	"d4 Nf6": {
		eco: "A45",
		name: "Indian Defence"
	},
	"d4 f5": {
		eco: "A80",
		name: "Dutch Defence"
	},
	"d4 e6": {
		eco: "A40",
		name: "Queen's Pawn, Horwitz Defence"
	},
	"d4 d6": {
		eco: "A41",
		name: "Old Indian Defence"
	},
	"d4 g6": {
		eco: "A40",
		name: "Modern Defence"
	},
	"d4 c5": {
		eco: "A43",
		name: "Old Benoni Defence"
	},
	"d4 d5 c4": {
		eco: "D06",
		name: "Queen's Gambit"
	},
	"d4 d5 c4 dxc4": {
		eco: "D20",
		name: "Queen's Gambit Accepted"
	},
	"d4 d5 c4 e6": {
		eco: "D30",
		name: "Queen's Gambit Declined"
	},
	"d4 d5 c4 e6 Nc3 Nf6 Bg5": {
		eco: "D50",
		name: "QGD, Classical Variation"
	},
	"d4 d5 c4 e6 Nc3 c5": {
		eco: "D32",
		name: "QGD, Tarrasch Defence"
	},
	"d4 d5 c4 c6": {
		eco: "D10",
		name: "Slav Defence"
	},
	"d4 d5 c4 c6 Nf3 Nf6 Nc3 dxc4": {
		eco: "D15",
		name: "Slav, Main Line"
	},
	"d4 d5 c4 c6 Nf3 Nf6 Nc3 e6": {
		eco: "D43",
		name: "Semi-Slav Defence"
	},
	"d4 d5 c4 Nc6": {
		eco: "D07",
		name: "Queen's Gambit, Chigorin Defence"
	},
	"d4 d5 c4 Bf5": {
		eco: "D06",
		name: "Queen's Gambit, Baltic Defence"
	},
	"d4 d5 Nf3": {
		eco: "D02",
		name: "Queen's Pawn, Zukertort"
	},
	"d4 d5 Bf4": {
		eco: "D00",
		name: "Queen's Pawn, London System"
	},
	"d4 d5 Nf3 Nf6 Bf4": {
		eco: "D02",
		name: "London System"
	},
	"d4 d5 e4": {
		eco: "D00",
		name: "Blackmar-Diemer Gambit"
	},
	"d4 d5 Nc3": {
		eco: "D00",
		name: "Queen's Pawn, Veresov Attack"
	},
	"d4 Nf6 c4": {
		eco: "A50",
		name: "Indian Game"
	},
	"d4 Nf6 c4 e6": {
		eco: "E00",
		name: "Indian, East Indian Defence"
	},
	"d4 Nf6 c4 e6 Nc3 Bb4": {
		eco: "E20",
		name: "Nimzo-Indian Defence"
	},
	"d4 Nf6 c4 e6 Nf3 b6": {
		eco: "E12",
		name: "Queen's Indian Defence"
	},
	"d4 Nf6 c4 e6 g3": {
		eco: "E00",
		name: "Catalan Opening"
	},
	"d4 Nf6 c4 g6": {
		eco: "E60",
		name: "King's Indian Defence"
	},
	"d4 Nf6 c4 g6 Nc3 Bg7 e4": {
		eco: "E70",
		name: "King's Indian, Main Line"
	},
	"d4 Nf6 c4 g6 Nc3 d5": {
		eco: "D80",
		name: "Grünfeld Defence"
	},
	"d4 Nf6 c4 c5": {
		eco: "A56",
		name: "Benoni Defence"
	},
	"d4 Nf6 c4 c5 d5 e6": {
		eco: "A60",
		name: "Modern Benoni"
	},
	"d4 Nf6 c4 c5 d5 b5": {
		eco: "A57",
		name: "Benko Gambit"
	},
	"d4 Nf6 c4 e5": {
		eco: "A56",
		name: "Budapest Gambit"
	},
	"d4 Nf6 Bg5": {
		eco: "A45",
		name: "Trompowsky Attack"
	},
	"d4 Nf6 Nf3 g6 Bf4": {
		eco: "A48",
		name: "London System"
	},
	"d4 f5 g3": {
		eco: "A81",
		name: "Dutch Defence, Fianchetto"
	},
	"d4 f5 c4 Nf6 g3 e6": {
		eco: "A90",
		name: "Dutch, Stonewall / Classical"
	},
	"c4 e5": {
		eco: "A20",
		name: "English Opening, Reversed Sicilian"
	},
	"c4 c5": {
		eco: "A30",
		name: "English, Symmetrical Variation"
	},
	"c4 Nf6": {
		eco: "A15",
		name: "English, Anglo-Indian Defence"
	},
	"c4 e6": {
		eco: "A13",
		name: "English Opening, Agincourt Defence"
	},
	"c4 c6": {
		eco: "A11",
		name: "English, Caro-Kann Defensive System"
	},
	"c4 g6": {
		eco: "A10",
		name: "English, Great Snake Variation"
	},
	"Nf3 d5": {
		eco: "A06",
		name: "Réti Opening"
	},
	"Nf3 d5 c4": {
		eco: "A09",
		name: "Réti Gambit"
	},
	"Nf3 Nf6 c4": {
		eco: "A15",
		name: "English, Anglo-Indian"
	},
	"Nf3 Nf6 g3": {
		eco: "A05",
		name: "King's Indian Attack"
	}
};
/** Longest-prefix opening lookup for a SAN move list. */
function detectOpening(san) {
	let found = null;
	const max = Math.min(san.length, 16);
	for (let i = 1; i <= max; i++) {
		const hit = BOOK[san.slice(0, i).join(" ")];
		if (hit) found = {
			...hit,
			ply: i
		};
	}
	return found;
}
/**
* Opening label after each ply (null while the position is still unnamed).
* Index 0 corresponds to the position after move 1.
*/
function openingByPly(san) {
	const out = [];
	let current = null;
	for (let i = 0; i < san.length; i++) {
		const hit = i < 16 ? BOOK[san.slice(0, i + 1).join(" ")] : void 0;
		if (hit) current = hit;
		out.push(current);
	}
	return out;
}
/** Full bot roster — every personality is a separately rated opponent. */
var BOTS = [
	{
		id: "pip",
		label: "Pip",
		blurb: "Just learned the moves",
		elo: 300,
		tier: "Beginner",
		depth: 1,
		blunder: .85,
		budget: 80,
		style: "wild"
	},
	{
		id: "bella",
		label: "Bella",
		blurb: "Loves pushing pawns",
		elo: 450,
		tier: "Beginner",
		depth: 1,
		blunder: .7,
		budget: 100,
		style: "balanced"
	},
	{
		id: "easy",
		label: "Rusty",
		blurb: "Blunders often",
		elo: 600,
		tier: "Beginner",
		depth: 1,
		blunder: .55,
		budget: 150,
		style: "greedy"
	},
	{
		id: "milo",
		label: "Milo",
		blurb: "Grabs every free piece",
		elo: 750,
		tier: "Beginner",
		depth: 2,
		blunder: .45,
		budget: 200,
		style: "greedy"
	},
	{
		id: "nova",
		label: "Nova",
		blurb: "Attacks with everything",
		elo: 900,
		tier: "Beginner",
		depth: 2,
		blunder: .38,
		budget: 250,
		style: "aggressive"
	},
	{
		id: "medium",
		label: "Casey",
		blurb: "Club beginner",
		elo: 1050,
		tier: "Intermediate",
		depth: 3,
		blunder: .28,
		budget: 400,
		style: "balanced"
	},
	{
		id: "sable",
		label: "Sable",
		blurb: "Sits back and defends",
		elo: 1200,
		tier: "Intermediate",
		depth: 3,
		blunder: .22,
		budget: 500,
		style: "defensive"
	},
	{
		id: "kite",
		label: "Kite",
		blurb: "Wild gambit player",
		elo: 1300,
		tier: "Intermediate",
		depth: 3,
		blunder: .2,
		budget: 550,
		style: "wild"
	},
	{
		id: "orin",
		label: "Orin",
		blurb: "Quiet positional grind",
		elo: 1400,
		tier: "Intermediate",
		depth: 4,
		blunder: .14,
		budget: 700,
		style: "positional"
	},
	{
		id: "hard",
		label: "Vera",
		blurb: "Sees basic tactics",
		elo: 1500,
		tier: "Intermediate",
		depth: 4,
		blunder: .1,
		budget: 900,
		style: "balanced"
	},
	{
		id: "raze",
		label: "Raze",
		blurb: "Relentless attacker",
		elo: 1650,
		tier: "Advanced",
		depth: 5,
		blunder: .07,
		budget: 1100,
		style: "aggressive"
	},
	{
		id: "brick",
		label: "Brick",
		blurb: "Fortress builder",
		elo: 1750,
		tier: "Advanced",
		depth: 5,
		blunder: .06,
		budget: 1200,
		style: "defensive"
	},
	{
		id: "juno",
		label: "Juno",
		blurb: "Sharp tactician",
		elo: 1900,
		tier: "Advanced",
		depth: 6,
		blunder: .04,
		budget: 1600,
		style: "balanced"
	},
	{
		id: "atlas",
		label: "Atlas",
		blurb: "Squeezes small edges",
		elo: 2050,
		tier: "Advanced",
		depth: 6,
		blunder: .02,
		budget: 1900,
		style: "positional"
	},
	{
		id: "sterling",
		label: "Sterling",
		blurb: "Strong club master",
		elo: 2200,
		tier: "Master",
		depth: 7,
		blunder: .01,
		budget: 2200,
		style: "balanced"
	},
	{
		id: "onyx",
		label: "Onyx",
		blurb: "Merciless attacker",
		elo: 2350,
		tier: "Master",
		depth: 7,
		blunder: 0,
		budget: 2600,
		style: "aggressive"
	},
	{
		id: "impossible",
		label: "Titan",
		blurb: "Deep search, no mercy",
		elo: 2500,
		tier: "Master",
		depth: 9,
		blunder: 0,
		budget: 3500,
		style: "balanced"
	}
];
var BOT_TIERS = [
	"Beginner",
	"Intermediate",
	"Advanced",
	"Master"
];
var getBot = (id) => BOTS.find((b) => b.id === id) ?? BOTS[5];
var VALUE = {
	p: 100,
	n: 320,
	b: 330,
	r: 500,
	q: 900,
	k: 2e4
};
var PST = {
	p: [
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		50,
		50,
		50,
		50,
		50,
		50,
		50,
		50,
		10,
		10,
		20,
		30,
		30,
		20,
		10,
		10,
		5,
		5,
		10,
		25,
		25,
		10,
		5,
		5,
		0,
		0,
		0,
		20,
		20,
		0,
		0,
		0,
		5,
		-5,
		-10,
		0,
		0,
		-10,
		-5,
		5,
		5,
		10,
		10,
		-20,
		-20,
		10,
		10,
		5,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	],
	n: [
		-50,
		-40,
		-30,
		-30,
		-30,
		-30,
		-40,
		-50,
		-40,
		-20,
		0,
		0,
		0,
		0,
		-20,
		-40,
		-30,
		0,
		10,
		15,
		15,
		10,
		0,
		-30,
		-30,
		5,
		15,
		20,
		20,
		15,
		5,
		-30,
		-30,
		0,
		15,
		20,
		20,
		15,
		0,
		-30,
		-30,
		5,
		10,
		15,
		15,
		10,
		5,
		-30,
		-40,
		-20,
		0,
		5,
		5,
		0,
		-20,
		-40,
		-50,
		-40,
		-30,
		-30,
		-30,
		-30,
		-40,
		-50
	],
	b: [
		-20,
		-10,
		-10,
		-10,
		-10,
		-10,
		-10,
		-20,
		-10,
		0,
		0,
		0,
		0,
		0,
		0,
		-10,
		-10,
		0,
		5,
		10,
		10,
		5,
		0,
		-10,
		-10,
		5,
		5,
		10,
		10,
		5,
		5,
		-10,
		-10,
		0,
		10,
		10,
		10,
		10,
		0,
		-10,
		-10,
		10,
		10,
		10,
		10,
		10,
		10,
		-10,
		-10,
		5,
		0,
		0,
		0,
		0,
		5,
		-10,
		-20,
		-10,
		-10,
		-10,
		-10,
		-10,
		-10,
		-20
	],
	r: [
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		5,
		10,
		10,
		10,
		10,
		10,
		10,
		5,
		-5,
		0,
		0,
		0,
		0,
		0,
		0,
		-5,
		-5,
		0,
		0,
		0,
		0,
		0,
		0,
		-5,
		-5,
		0,
		0,
		0,
		0,
		0,
		0,
		-5,
		-5,
		0,
		0,
		0,
		0,
		0,
		0,
		-5,
		-5,
		0,
		0,
		0,
		0,
		0,
		0,
		-5,
		0,
		0,
		0,
		5,
		5,
		0,
		0,
		0
	],
	q: [
		-20,
		-10,
		-10,
		-5,
		-5,
		-10,
		-10,
		-20,
		-10,
		0,
		0,
		0,
		0,
		0,
		0,
		-10,
		-10,
		0,
		5,
		5,
		5,
		5,
		0,
		-10,
		-5,
		0,
		5,
		5,
		5,
		5,
		0,
		-5,
		0,
		0,
		5,
		5,
		5,
		5,
		0,
		-5,
		-10,
		5,
		5,
		5,
		5,
		5,
		0,
		-10,
		-10,
		0,
		5,
		0,
		0,
		0,
		0,
		-10,
		-20,
		-10,
		-10,
		-5,
		-5,
		-10,
		-10,
		-20
	],
	k: [
		-30,
		-40,
		-40,
		-50,
		-50,
		-40,
		-40,
		-30,
		-30,
		-40,
		-40,
		-50,
		-50,
		-40,
		-40,
		-30,
		-30,
		-40,
		-40,
		-50,
		-50,
		-40,
		-40,
		-30,
		-30,
		-40,
		-40,
		-50,
		-50,
		-40,
		-40,
		-30,
		-20,
		-30,
		-30,
		-40,
		-40,
		-30,
		-30,
		-20,
		-10,
		-20,
		-20,
		-20,
		-20,
		-20,
		-20,
		-10,
		20,
		20,
		0,
		0,
		0,
		0,
		20,
		20,
		20,
		30,
		10,
		0,
		0,
		10,
		30,
		20
	]
};
/** Static evaluation from White's point of view, in centipawns. */
function evaluate(chess) {
	if (chess.isCheckmate()) return chess.turn() === "w" ? -1e5 : 1e5;
	if (chess.isDraw() || chess.isStalemate()) return 0;
	let score = 0;
	const board = chess.board();
	for (let r = 0; r < 8; r++) for (let f = 0; f < 8; f++) {
		const cell = board[r][f];
		if (!cell) continue;
		const idx = cell.color === "w" ? r * 8 + f : (7 - r) * 8 + f;
		const v = VALUE[cell.type] + (PST[cell.type]?.[idx] ?? 0);
		score += cell.color === "w" ? v : -v;
	}
	return score;
}
function ordered(chess) {
	return chess.moves({ verbose: true }).sort((a, b) => scoreMove(b) - scoreMove(a));
}
function scoreMove(m) {
	let s = 0;
	if (m.captured) s += 10 * VALUE[m.captured] - VALUE[m.piece];
	if (m.promotion) s += 800;
	if (m.san.includes("+")) s += 50;
	return s;
}
var TIMEOUT = { timeout: true };
var deadline = Infinity;
/** Capture-only search so the bot stops hanging pieces at the horizon. */
function quiesce(chess, alpha, beta) {
	const stand = evaluate(chess);
	const maximizing = chess.turn() === "w";
	if (maximizing) {
		if (stand >= beta) return beta;
		if (stand > alpha) alpha = stand;
	} else {
		if (stand <= alpha) return alpha;
		if (stand < beta) beta = stand;
	}
	const caps = chess.moves({ verbose: true }).filter((m) => m.captured || m.promotion).sort((a, b) => scoreMove(b) - scoreMove(a));
	for (const m of caps) {
		chess.move(m);
		const val = quiesce(chess, alpha, beta);
		chess.undo();
		if (maximizing) {
			if (val >= beta) return beta;
			if (val > alpha) alpha = val;
		} else {
			if (val <= alpha) return alpha;
			if (val < beta) beta = val;
		}
	}
	return maximizing ? alpha : beta;
}
function search(chess, depth, alpha, beta) {
	if (Date.now() > deadline) throw TIMEOUT;
	if (chess.isGameOver()) return evaluate(chess);
	if (depth === 0) return quiesce(chess, alpha, beta);
	const maximizing = chess.turn() === "w";
	let best = maximizing ? -Infinity : Infinity;
	for (const m of ordered(chess)) {
		chess.move(m);
		const val = search(chess, depth - 1, alpha, beta);
		chess.undo();
		if (maximizing) {
			best = Math.max(best, val);
			alpha = Math.max(alpha, val);
		} else {
			best = Math.min(best, val);
			beta = Math.min(beta, val);
		}
		if (beta <= alpha) break;
	}
	return best;
}
/** Scores every root move with iterative deepening, best-first. */
function rankedMoves(fen, depth, budgetMs = 4e3) {
	const chess = new Chess(fen);
	let moves = ordered(chess);
	if (!moves.length) return [];
	const maximizing = chess.turn() === "w";
	deadline = Date.now() + budgetMs;
	let finalScores = /* @__PURE__ */ new Map();
	for (let d = 1; d <= depth; d++) {
		const scores = /* @__PURE__ */ new Map();
		try {
			let alpha = -Infinity;
			let beta = Infinity;
			for (const m of moves) {
				chess.move(m);
				const val = search(chess, d - 1, alpha, beta);
				chess.undo();
				scores.set(m.san, val);
				if (maximizing) alpha = Math.max(alpha, val);
				else beta = Math.min(beta, val);
			}
		} catch {
			break;
		}
		finalScores = scores;
		moves = [...moves].sort((a, b) => {
			const sa = scores.get(a.san) ?? (maximizing ? -Infinity : Infinity);
			const sb = scores.get(b.san) ?? (maximizing ? -Infinity : Infinity);
			return maximizing ? sb - sa : sa - sb;
		});
		const top = finalScores.get(moves[0].san) ?? 0;
		if (Math.abs(top) > 9e4) break;
	}
	deadline = Infinity;
	const fallback = evaluate(chess);
	return moves.map((m) => ({
		move: m,
		score: finalScores.get(m.san) ?? fallback
	}));
}
/** Best move for the side to move at a given search depth. */
function bestMove(fen, depth, budgetMs = 4e3) {
	const chess = new Chess(fen);
	const ranked = rankedMoves(fen, depth, budgetMs);
	if (!ranked.length) return {
		move: null,
		score: evaluate(chess)
	};
	return {
		move: ranked[0].move,
		score: ranked[0].score
	};
}
var CENTER = /* @__PURE__ */ new Set([
	"d4",
	"d5",
	"e4",
	"e5",
	"c4",
	"c5",
	"f4",
	"f5"
]);
/** Personality bonus in centipawns, from the moving side's point of view. */
function styleBonus(m, style) {
	const cap = m.captured ? VALUE[m.captured] : 0;
	const check = m.san.includes("+") || m.san.includes("#");
	switch (style) {
		case "aggressive": return (check ? 70 : 0) + cap * .25 + (m.piece !== "p" ? 15 : 0);
		case "greedy": return cap * .6 + (m.promotion ? 60 : 0);
		case "defensive": return (m.san === "O-O" || m.san === "O-O-O" ? 60 : 0) - (check ? 20 : 0) + (cap ? 10 : 25);
		case "positional": return (CENTER.has(m.to) ? 35 : 0) + (m.san.startsWith("O-O") ? 55 : 0) + (m.piece === "n" || m.piece === "b" ? 15 : 0);
		case "wild": return (check ? 50 : 0) + Math.random() * 90 - (m.piece === "q" ? 0 : 10);
		default: return 0;
	}
}
/** Picks the bot's move using its strength and personality. */
function botMove(fen, level) {
	const chess = new Chess(fen);
	const moves = chess.moves({ verbose: true });
	if (!moves.length) return null;
	const bot = getBot(level);
	if (bot.blunder && Math.random() < bot.blunder) {
		const captures = moves.filter((m) => m.captured);
		const pool = captures.length && Math.random() > .5 ? captures : moves;
		return pool[Math.floor(Math.random() * pool.length)];
	}
	const ranked = rankedMoves(fen, bot.depth, bot.budget);
	if (!ranked.length) return moves[0];
	const sign = chess.turn() === "w" ? 1 : -1;
	const top = ranked[0].score * sign;
	const tolerance = bot.style === "balanced" ? 0 : Math.max(20, 120 - bot.elo / 25);
	const pool = ranked.filter((r) => top - r.score * sign <= tolerance);
	if (pool.length <= 1) return ranked[0].move;
	let choice = pool[0];
	let bestAdj = -Infinity;
	for (const r of pool) {
		const adj = r.score * sign + styleBonus(r.move, bot.style);
		if (adj > bestAdj) {
			bestAdj = adj;
			choice = r;
		}
	}
	return choice.move;
}
function tagFor(loss) {
	if (loss <= 10) return "Best";
	if (loss <= 30) return "Great";
	if (loss <= 70) return "Good";
	if (loss <= 150) return "Inaccuracy";
	if (loss <= 300) return "Mistake";
	return "Blunder";
}
function suspicionOf(match, accuracy, moves) {
	if (moves < 12) return "clean";
	if (match >= 92 && accuracy >= 97) return "high";
	if (match >= 82 && accuracy >= 93) return "review";
	return "clean";
}
/** Reviews a finished game move by move using a shallow search. */
function reviewGame(history, depth = 2) {
	const chess = new Chess();
	const moves = [];
	const counts = {
		Best: 0,
		Great: 0,
		Good: 0,
		Inaccuracy: 0,
		Mistake: 0,
		Blunder: 0
	};
	const losses = {
		w: [],
		b: []
	};
	const matches = {
		w: [],
		b: []
	};
	const sanList = history.map((m) => m.san);
	const bookLine = detectOpening(sanList);
	const perPly = openingByPly(sanList);
	history.forEach((m, i) => {
		const color = chess.turn();
		const top = bestMove(chess.fen(), depth);
		const before = top.score;
		chess.move({
			from: m.from,
			to: m.to,
			promotion: m.promotion
		});
		const after = bestMove(chess.fen(), Math.max(1, depth - 1)).score;
		const raw = color === "w" ? before - after : after - before;
		const loss = Math.max(0, Math.min(1e3, Math.round(raw)));
		const tag = tagFor(loss);
		counts[tag] += 1;
		losses[color].push(loss);
		matches[color].push(top.move?.san === m.san ? 1 : 0);
		const book = perPly[i];
		moves.push({
			ply: i + 1,
			san: m.san,
			color,
			loss,
			tag,
			eco: book?.eco,
			opening: book?.name,
			book: Boolean(bookLine && i < bookLine.ply)
		});
	});
	const acc = (list) => list.length ? Math.round(list.reduce((sum, l) => sum + 100 * Math.exp(-l / 180), 0) / list.length * 10) / 10 : 100;
	const stat = (color) => {
		const list = matches[color];
		const match = list.length ? Math.round(list.reduce((a, b) => a + b, 0) / list.length * 1e3) / 10 : 0;
		const accuracy = acc(losses[color]);
		return {
			engineMatch: match,
			accuracy,
			moves: list.length,
			suspicion: suspicionOf(match, accuracy, list.length)
		};
	};
	return {
		moves,
		accuracy: {
			w: acc(losses.w),
			b: acc(losses.b)
		},
		counts,
		opening: bookLine,
		fairPlay: {
			w: stat("w"),
			b: stat("b")
		}
	};
}
/** Standard Elo update. result: 1 win, 0.5 draw, 0 loss. */
function nextElo(current, opponent, result, k = 32) {
	const expected = 1 / (1 + 10 ** ((opponent - current) / 400));
	return Math.round(current + k * (result - expected));
}
/** Each bot has its own separate rating, seeded near its strength. */
function startElo(level) {
	return Math.max(300, getBot(level).elo - 200);
}
var eloKey = (level) => `clickchess.elo.${level}`;
function readElo(level) {
	if (typeof window === "undefined") return startElo(level);
	const raw = window.localStorage.getItem(eloKey(level));
	const n = raw ? Number(raw) : NaN;
	return Number.isFinite(n) ? n : startElo(level);
}
function writeElo(level, value) {
	if (typeof window === "undefined") return;
	window.localStorage.setItem(eloKey(level), String(Math.max(100, value)));
}
function readAllElo() {
	return Object.fromEntries(BOTS.map((b) => [b.id, readElo(b.id)]));
}
//#endregion
export { getBot as a, readAllElo as c, startElo as d, writeElo as f, evaluate as i, readElo as l, BOT_TIERS as n, nextElo as o, botMove as r, rankedMoves as s, BOTS as t, reviewGame as u };
